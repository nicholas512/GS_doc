# -*- coding: utf-8 -*
# from ecmwfapi.api import ECMWFDataServer
# from era_interim import *
# from globsim import *
# from generic import *

name = "globsim"